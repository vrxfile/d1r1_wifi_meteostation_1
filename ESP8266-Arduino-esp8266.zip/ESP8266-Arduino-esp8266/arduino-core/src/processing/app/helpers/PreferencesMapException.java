package processing.app.helpers;

@SuppressWarnings("serial")
public class PreferencesMapException extends Exception {

  public PreferencesMapException(String message) {
    super(message);
  }

}
