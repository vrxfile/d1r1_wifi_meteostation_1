package cc.arduino.builder;

import processing.app.BaseNoGui;

public class ArduinoBuilder {

  public static void main(String[] args) throws Exception {
    BaseNoGui.main(args);
  }

}
